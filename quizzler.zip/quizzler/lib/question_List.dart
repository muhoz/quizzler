//////////*************** This file is the class for the questions lists (- include all the questions to be listed on the quizz)
//                                                                        - functions to :  1 - increment the question number to launch the next question
//                                                                                          2 - boolean to know if the quiz has reached the end
//                                                                                          3 - function to read the next question from the bank
//                                                                                          4 - function to read the answer from the bank
//                                                                                          5 - function to reset the question number


import 'questions_answers.dart';

class Questions_List {
  int _questionNumber = 0;
  bool _stop = false;


  //question bank
  List<Question> _questions_Bank = [
    Question(
        question: 'Some cats are actually allergic to humans', answer: true),
    Question(
        question: 'You can lead a cow down stairs but not up stairs.',
        answer: false),
    Question(
        question: 'Approximately one quarter of human bones are in the feet.',
        answer: true),
    Question(question: 'A slug\'s blood is green.', answer: true),
    Question(
        question: 'Buzz Aldrin\'s mother\'s maiden name was \"Moon\".',
        answer: true),
    Question(
        question: 'It is illegal to pee in the Ocean in Portugal.',
        answer: true),
    Question(
        question:
            'No piece of square dry paper can be folded in half more than 7 times.',
        answer: false),
    Question(
        question:
            'In London, UK, if you happen to die in the House of Parliament, you are technically entitled to a state funeral, because the building is considered too sacred a place.',
        answer: true),
    Question(
        question:
            'The loudest sound produced by any animal is 188 decibels. That animal is the African Elephant.',
        answer: false),
    Question(
        question:
            'The total surface area of two human lungs is approximately 70 square metres.',
        answer: true),
    Question(
        question: 'Google was originally called \"Backrub\".', answer: true),
    Question(
        question:
            'Chocolate affects a dog\'s heart and nervous system; a few ounces are enough to kill a small dog.',
        answer: true),
    Question(
        question:
            'In West Virginia, USA, if you accidentally hit an animal with your car, you are free to take it home to eat.',
        answer: true),
  ];

  //increment the question number to launch the next question
  void questionNumbe() {
    if (_questionNumber < _questions_Bank.length - 1) {
      _questionNumber++;
      print(_questionNumber);
    }
  }

  //boolean to know if the quiz has reached the end
  bool isFinished() {
    if (_questionNumber == _questions_Bank.length - 1) {
      _stop = true;
      print(_stop);
    } else {
      _stop = false;
      print(_stop);
    }
    return _stop;
  }

  //function to read the next question from the bank
  String getQuestion_Bank() {
    return _questions_Bank[_questionNumber].question;
  }

  //function to read the answer from the bank
  bool getAnswer_Bank() {
    return _questions_Bank[_questionNumber].answer;
  }

  //function to reset the question number
  void resetNum() {
    _questionNumber = 0;
  }
}
