/////***********************class to create new question objects = question + answer properties******////////

class Question {
  String question;
  bool answer;

  Question({this.question, this.answer}) {}
}
