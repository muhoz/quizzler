import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'questions_answers.dart';
import 'question_List.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

Questions_List question_list = Questions_List();

void main() {
  runApp(quizzler());
}


class quizzler extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.0),
            child: quizz(),
          ),
        ),
      ),
    );
  }
}

class quizz extends StatefulWidget {
  @override
  _quizzState createState() => _quizzState();
}

class _quizzState extends State<quizz> {
  List<Icon> scoreKeeper = [];                      //scorekeeper list
  Color borderAnswerColor = Colors.black;           //border color of the score notifier
  int score=0;                                      //score variable
  void answerCheck(bool answerPicked) {
    setState(() {
      bool answer = question_list.getAnswer_Bank();
      if (answer == answerPicked) {
        scoreKeeper.add(
          Icon(                               //green check for the score keeper
            Icons.check,
            color: Colors.green,
            size: 30,
          ),
        );
        score = score +10;                                 //add ten points in case of a good answer
        borderAnswerColor = Colors.green;
        //print('True');
        Future.delayed(Duration(seconds: 2), () {          //change the border color to black after the checking of the answer
          borderAnswerColor = Colors.black;
          setState(() {
          });
        });
      } else {
        scoreKeeper.add(
          Icon(                                            //change the border color of the notifier to red
            Icons.close,
            color: Colors.red,
            size: 30,
          ),
        );
        score-=10;                                                    //remove ten points from the score
        borderAnswerColor = Colors.red;
        // print('False');
        Future.delayed(Duration(seconds: 2), () {                    //change the border color to black after the checking of the answer
          borderAnswerColor = Colors.black;
          setState(() {
          });
        });
      }
      if (question_list.isFinished() == true) {                       //test if the question list hqs reached the end
        Alert(  type : AlertType.success,
                context: context,
                title: "FINISHED",
                desc: "You have reached the end of the quizz.")
            .show();
        question_list.resetNum();
        scoreKeeper.clear();
        score = 0;
      } else {
        print('continue');
      }
      //increment the question number
      question_list.questionNumbe();
    });
  }


  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children:[
            Expanded(
              child: Text("Quizzler",style: TextStyle(fontSize: 50.0, color: Colors.blueAccent,fontFamily: "Lobster",shadows: [
                Shadow(
                  blurRadius: 10.0,
                  color: Colors.lightBlueAccent,
                  offset: Offset(2.0, 2.0),
                ),
              ],),textAlign: TextAlign.center,),
            ),    //title QUIZZLER
            Card(
              elevation: 10,
              margin: EdgeInsets.all(1),
              shape: CircleBorder(side : BorderSide(color: borderAnswerColor,width: 3)),
              child: Padding(padding: EdgeInsets.all(10)
                  ,child: Text("$score",style: TextStyle(fontSize: 30,fontFamily: "Lobster"),textAlign: TextAlign.right,)),
            )         //score notifierm green for good answer, red for false, black by default
    ]
        ),
        Expanded(
          flex: 5,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10.0),
            child: Card(
              elevation: 20,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
              child: Center(
                child: Text(
                  question_list.getQuestion_Bank(),
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 30.0, color: Colors.black,fontFamily: "Lobster"),
                ),
              ),
            ),
          ),
        ),        //Main card where the questions will be displayed
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              elevation: 10,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              color: Colors.green,
              child: Center(
                child: TextButton(
                    child: Text(
                      "True",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 25.0, color: Colors.white,fontFamily: "Lobster"),
                    ),
                    onPressed: () {
                      answerCheck(true);
                    }),
              ),
            ),
          ),
        ),        //'True' card
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              elevation: 10,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              color: Colors.red,
              child: Center(
                child: TextButton(
                  child: Text(
                    "False",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 25.0, color: Colors.white,fontFamily: "Lobster"),
                  ),
                  onPressed: () {
                    answerCheck(false);
                  },
                ),
              ),
            ),
          ),
        ),        //'False' card
        Row(
          children: scoreKeeper,
        ),             //Row to display the status of the past answers
      ],
    );
  }
}
